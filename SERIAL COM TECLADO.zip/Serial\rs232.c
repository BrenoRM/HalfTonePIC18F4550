/*			GCEM - LUCAS DIEGO					*/
/*	A APLICACAO CONSISTE EM UMA COMUNICACAO 	*/
/*	DA PLACA COM O COMPUTADOR ATRAVES DO 		*/
/*	PERIFERICO UART(PORTA SERIAL), NA QUAL		*/
/*	O QUE E DIGITADO NO TECLADO DA PLACA 		*/
/*	APARECE NO TERMINAL SERIAL(DOCKLIGHT)		*/
/*	E O CARACTERE QUE SE DIGITA NO TERMINAL		*/
/*	APARECE NO DISPLAY ALFANUMERICO				*/
/*												*/
/*		REQUISITOS PARA A UTILIZACAO			*/
/*			DA APLICACAO NA PLACA:				*/
/*		JUMPERS JP21 E JP22 NA POSICAO 1		*/
/*		DIG1 A DIG 4 DESABILITADOS				*/
/*		APOS A GRAVACAO REMOVER O GRAVADOR 		*/
/*		PARA EVITAR CONFLITOS NOS PINOS			*/
/*		PGD E PGC								*/



// Bibliotecas
#include <P18F4520.h>
#include <usart.h>
#include <stdio.h>

// Oscilador e outras definicoes de registradores	
#pragma config OSC     	= HS     // (8 MHz)
#pragma config IESO     = OFF
#pragma config PWRT     = OFF
#pragma config BORV     = 3
#pragma config WDT      = OFF
#pragma config WDTPS    = 32768
#pragma config MCLRE    = OFF
#pragma config LPT1OSC  = OFF
#pragma config PBADEN   = OFF
#pragma config STVREN   = ON
#pragma config LVP      = OFF

// Defini��es 
#define OUT 0		// defini��o de dire��o de I/O
#define IN 1		// defini��o de dire��o de I/O

// Defini��es de Hardware
// Para LCD
#define RS PORTEbits.RE0
#define EN PORTEbits.RE1
#define DISPLAY PORTD
#define RS_DIR DDREbits.RE0
#define EN_DIR DDREbits.RE1
#define DISPLAY_DIR DDRD

// Para Teclado
// Pinos
#define C0 	PORTBbits.RB0 
#define C1 	PORTBbits.RB1
#define C2 	PORTBbits.RB2
#define C3 	PORTBbits.RB3
#define L3 	PORTBbits.RB7
#define L2 	PORTBbits.RB6
#define L1 	PORTBbits.RB5
#define L0	PORTBbits.RB4
// Dire��o de dados dos pinos
#define C0_DIR	DDRBbits.RB0
#define C1_DIR	DDRBbits.RB1
#define C2_DIR	DDRBbits.RB2
#define C3_DIR	DDRBbits.RB3
#define L0_DIR	DDRBbits.RB4
#define L1_DIR	DDRBbits.RB5
#define L2_DIR	DDRBbits.RB6
#define L3_DIR	DDRBbits.RB7

#include "LCD8.h"		//(OFERTADA PELA PROPRIA EXSTO)
#include "Keyboard.c"	// ACONSELHO LER O ARQUIVO PARA VER A TECNICA UTILIZADA

void main (void)
{
	const unsigned char msg_serial[] = "\n\n\rDigite uma tecla:";
	const unsigned char msg_lcd[] = "  Teste Serial";
	char tecla,rx;

	LATD = 0x00;
	DDRD = 0x00;	

	OpenLCD();		//(FUNCAO OFERTADA PELA PROPRIA EXSTO NA BIBLIOTECA LCD8.H)
	openKeyboard();	//(FUNCAO IMPLEMENTADA NO ARQUIVO KEYBOARD.C)
	OpenUSART(	USART_TX_INT_OFF & 
				USART_RX_INT_OFF & 
				USART_ASYNCH_MODE & 
				USART_EIGHT_BIT &
				USART_CONT_RX &
				USART_BRGH_HIGH,50);

	putsUSART(msg_serial);
	PrintLCD(msg_lcd);

	while(1){
		tecla = getKey();		//VERIFICA SE ALGUMA TECLA FOI PRESSIONADA
		if(tecla){
			putcUSART(tecla);	//IMPRIME A TECLA NO TERMINAL (FUNCAO OFERTADA PELA PROPRIA MICROCHIP NA BIBLIOTECA USART.H)
			while(getKey());	//ATRASO PARA A TECLA PRESSIONADA
		}

		if(DataRdyUSART()){		//MACRO DE VERIFICACAO DA FLAG DO PERIFERICO UART (CASO HAJA ALGO A SER LIDO NO BUFFER SERA SETADO PARA 1)
			rx = getcUSART();	//RECUPERA DO BUFFER DA UART UM CARACTERE (FUNCAO OFERTADA PELA PROPRIA MICROCHIP NA BIBLIOTECA USART.H)
			GotoXYLCD(7,2);
			if(rx == 13 || rx == 10) PutLCD(' ');	//CASO SEJA DIGITADO O ENTER OU O RETORNO DE CARRO '\r' SERA MOSTRADO O ESPACO VAZIO
			else PutLCD(rx);	//ESCREVE NO LCD O VALOR DO CARACTERRE	(FUNCAO OFERTADA PELA PROPRIA EXSTO NA BIBLIOTECA LCD8.H)
		}
	}
}

